<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ConjuntosResidencial extends Model
{
    //
}
