<?php

namespace App\Http\Controllers;
use Illuminate\Database\QueryException;
use App\Valerian\ValerianPropertie;
use App\Valerian\ValerianUtil;
use Illuminate\Http\Request;
use App\Apartamentos;
use App\Bloques;
class ControladorApartamento extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
        $this->validarLista($request->all())->validate();
        $data=Bloques::join("apartamentos","bloques.id","apartamentos.id_bloque")
                      ->select("apartamentos.numero as apartamentos","bloques.numero as bloques","apartamentos.id")
                      ->where("apartamentos.numero","like",".".$request->buscar."%");
        return response()->json(["data"=>$data]);   
    }
     /**
     * Get a validator for an incoming registration request.
     * validacion de la busqueda de apartamentos listar index
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    private function validarLista(array $data)
    {

        return Validator::make($data,
        [
          'buscar'=> 'required|number|max:255',
        ],
        [
          'buscar.required'=>ValerianPropertie::get('MSG_BUSCAR'),
        ]
      );

    }
   /**
     * Get a validator for an incoming registration request.
     * validacion de la insercion y actualizacion una obligacion
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    private function validar(array $data)
    {

        return Validator::make($data,
        [
            'id'          => 'required|number',
            'id_bloque'           => 'required|number',
        ],
        [
          'id.required'=>ValerianPropertie::get('MSG_ID'),
        'id_bloque.required'=>ValerianPropertie::get('MSG_ID'),
   
          ]
      );

    }
    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
        $apartamento=Apartamentos::find($request->id);
        $bloque =Bloques::find($request->id_bloque);        
        $this->registrarActualizar($request,$apartamento,$bloque);
    
    }
    private function registrarActualizar(Request $request,$apartamento,$bloque)
    {
        $this->validar($request->all())->validate();
    
        try{
            $apartamentos->id=$request->id;
            $apartamento->numero=$request->numero;
            $apartamento->id_bloque=$request->id_bloque;
            $apartamento->save();
            return response()->json(["data"=>$apartamento]);
        } catch(\Illuminate\Database\QueryException $ex){ 
            return response()->json(["error"=>$ex->getMessage()],400); 
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $apartamento=Apartamentos::find($id);
        $bloque =Bloques::find($request->id_bloque);        
        $this->registrarActualizar($request,$apartamento,$bloque);
    
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
