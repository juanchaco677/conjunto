<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Usuarios;
use App\Valerian\ValerianUtil;
use App\Valerian\ValerianPropertie;
use Illuminate\Database\QueryException;
use Tymon\JWTAuth\JWTAuth;
class ControladorUsuario extends Controller
{
    private $jwtauth;
    private $usuarios;
    public function __construct(Usuarios $usuarios,JWTAuth $jwtauth){
        $this->usuarios=$usuarios;
        $this->jwtauth=$jwtauth;
    }
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
        /**
     * Get a validator for an incoming registration request.
     * validacion de la insercion y actualizacion de cualquier usuario
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    private function validar(array $data)
    {

        return Validator::make($data,
        [
            'nombre_uno'            => 'required|string|max:30',
            'apellido_dos'          => 'required|string|max:30',
            'email'           => 'required|string|max:255',
            'password'          => 'required|string|max:255',
          ],
        [
          'nombre_uno.required'=>ValerianPropertie::get('MSG_NOMBRE_UNO'),
          'apellido_uno.required'=>ValerianPropertie::get('MSG_APELLIDO_UNO'),
          'email.required'=>ValerianPropertie::get('MSG_CORREO'),
          'password.required'=>ValerianPropertie::get('MSG_CONTRASENA'),
       ]
      );

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validar($request->all())->validate();
        $usuario=new Usuarios();
        $id=Usuarios::max('id');
        $id=ValerianUtil::agregarCodigo(date("Y"), $id);
        $this->crearActualizarRegistro($request,$usuario,$id);
    }

    private function crearActualizarRegistro(Request $request,$usuario,$id){
       try { 
            $usuario->id=$id;
            $usuario->nombre_uno=$request->nombre_uno;
            $usuario->nombre_dos=empty($request->nombre_dos)?null:$request->nombre_dos;
            $usuario->apellido_uno=$request->apellido_uno;
            $usuario->apellido_dos=empty($request->apellido_dos)?null:$request->apellido_dos;
            $usuario->email=$request->email;
            $usuario->password=bcrypt($request->password);
            $usuario->alias=empty($request->alias)?null:$request->alias;
            $usuario->celular=empty($request->celular)?null:$request->celular;
            $usuario->telefono=empty($request->telefono)?null:$request->telefono;
            $usuario->id_admi_pro=empty($request->id_admi_pro)?null:$request->id_admi_pro;
            $usuario->save();
            return response()->json(["data"=>$usuario],200);
        } catch(\Illuminate\Database\QueryException $ex){ 
            return response()->json(["error"=>$ex->getMessage()],400); 
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $usuario=Usuarios::find($id);
        $this->crearActualizarRegistro($request,$usuario,$id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }

    public function sesion(Request $request)
    {
        // grab credentials from the request

        $credentials = $request->only('email', 'password');

        // attempt to verify the credentials and create a token for the user
        if (! $token = $this->jwtauth->attempt($credentials)) {
            return response()->json(['error' => 'las credenciales del usuario no son correctas'], 401);
        }
        
        return response()->json(['token' => compact('token')], 201);

    }

    public function autorizarUsuario(Request $request){

        $user = $this->jwtauth->toUser($request->token);
        return response()->json(['data' => $user]);

    }
    public function cerrar(){

        $token=$this->jwtauth->getToken();
        $this->jwtauth->invalidate($token);
        return response()->json(['data'=>true]);
    
    }

    public function refresh(){
    
        $token=$this->jwtauth->getToken();
        $token=$this->jwtauth->refresh($token);
        return response()->json(compact('token'));
    
    }
}
