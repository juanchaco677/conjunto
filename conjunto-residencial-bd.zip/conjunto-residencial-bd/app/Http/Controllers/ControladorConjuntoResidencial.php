<?php

namespace App\Http\Controllers;
use Illuminate\Database\QueryException;
use App\Valerian\ValerianPropertie;
use App\Valerian\ValerianUtil;
use Illuminate\Http\Request;
use App\ConjuntosResidencial;
use App\CuotasAdministracion;
use App\Coordenadas;
use App\Usuarios;



class ControladorConjuntoResidencial extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validar($request->all())->validate();
        $conjunto=new ConjuntosResidencial();
        $this->crearActualizarRegistro($request,$conjunto,$cuota);
    }
    /**
     * Get a validator for an incoming registration request.
     * validacion de la insercion y actualizacion de un conjunto residencial
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    private function validar(array $data)
    {

        return Validator::make($data,
        [
            'nombre'            => 'required|string|max:60',
            'direccion'          => 'required|string|max:60',
            //'valor_mensual'=> 'required|number',
            'id_administrador'=> 'required|string',
        ],
        [
          'nombre.required'=>ValerianPropertie::get('MSG_NOMBRE_CONJUNTO'),
          'direccion.required'=>ValerianPropertie::get('MSG_DIRECCION_CONJUNTO'),
          //'valor_mensual.required'=>ValerianPropertie::get('MSG_CUOTA'),
          'id_administrador.required'=>ValerianPropertie::get('MSG_ADMINISTRADOR'),
         ]
      );

    }

    /**
     * metodo para crear y actualizar un conjunto residencial
     */
    private function crearActualizarRegistro(Request $request,$conjunto,$cuota)
    {
        try{ 
            $conjunto->nombre=$request->nombre;
            $conjunto->direccion=$request->direccion;
            $conjunto->telefono=$request->telefono;
            $conjunto->celular=$request->celular;          
            $conjunto->id_coordenada=$request->id_coordenada;
            $conjunto->id_administrador=$request->id_administrador;
            $conjunto->save();
            return response()->json(["data"=>$conjunto]);
        } catch(\Illuminate\Database\QueryException $ex){ 
            return response()->json(["error"=>$ex->getMessage()],400); 
        }
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validar($request->all())->validate();
        $conjunto=ConjuntosResidencial::find($id);
        $this->crearActualizarRegistro($request,$conjunto);

    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
