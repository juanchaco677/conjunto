<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Obligaciones;
use App\Valerian\ValerianUtil;
use App\Valerian\ValerianPropertie;
use Illuminate\Database\QueryException;
class ControladorObligacion extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //

        
    }

   /**
     * Get a validator for an incoming registration request.
     * validacion de la insercion y actualizacion una obligacion
     * @param  array  $data
     * @return \Illuminate\Contracts\Validation\Validator
     */
    private function validar(array $data)
    {

        return Validator::make($data,
        [
            'id_factura'          => 'required|string|max:15',
            'id_propietario_inquilino'           => 'required|string|max:15',
        ],
        [
          'id_factura.required'=>ValerianPropertie::get('MSG_FACTURA'),
          'id_propietario_inquilino.required'=>ValerianPropertie::get('MSG_PRO_INQUI'),
        ]
      );

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $obligacion=Obligaciones::where("id_propietario_inquilino","=",$request->id_propietario_inquilino)
                                ->where("ano","=",date("Y"));
        $this->validar($request->all())->validate();
    
        if(empty($obligacion)){
            $obligacion=new Obligaciones();
            $id=Obligaciones::max('id');
            $id=ValerianUtil::agregarCodigo(date("Y"), $id);    
            $this->crearActualizarRegistro($request,$obligacion,$id);
        }else{

            return response()->json(["data"=>$obligacion]);
        }
    }
    private function crearActualizarRegistro(Request $request,$obligacion,$id)
    {
        try{
            $obligacion->id=$id;
            $obligacion->ano=(int)date("Y");
            $obligacion->id_factura=$request->id_factura;
            $obligacion->id_propietario_inquilino=$request->id_propietario_inquilino;
            $obligacion->save();
            return response()->json(["data"=>$obligacion]);
        } catch(\Illuminate\Database\QueryException $ex){ 
            return response()->json(["error"=>$ex->getMessage()],400); 
        }
    }
    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $this->validar($request->all())->validate();
        $obligacion=Obligaciones::find($id);
        $this->crearActualizarRegistro($request,$obligacion,$id);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
