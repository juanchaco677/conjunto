<?php

/**
 * Created by PhpStorm.
 * User: Juan Camilo
 * Date: 09/07/2017
 * Time: 10:30 AM
 */
namespace App\Valerian;

class ValerianConstante {
	const IDINICIAL = '000000000000001';

}
