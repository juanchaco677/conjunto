<?php
namespace App\Valerian;

use Illuminate\Support\Facades\Config;

use App\Valerian\ValerianUtil;

class ValerianPropertie
{

	public function __construct ( )
	{

	}

	public static function get (
		$key)
	{
		try {
			return Config :: get (
				'properties.' .
				$key );

		} catch (EvssaException $e) {
				EvssaUtil.agregarMensajeError("No existe el properties ".$key);
		}

	}

	public static function getUpper (
		$key)
	{
		return strtoupper (
			Config :: get (
				'properties.' .
					 $key ) );
	}
}
