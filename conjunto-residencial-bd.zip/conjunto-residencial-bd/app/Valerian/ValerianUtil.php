<?php

namespace App\Valerian;

use App\Valerian\ValerianConstante;

class ValerianUtil {


    /**
     * constructor de la clase recibe un archivo
     * @param  $file
     */
    public function __construct ()
    {

    }

    public static function agregarCodigo($inicial,$id){
      return ((string)$inicial).''.empty($id)?str_pad("1", 12, "0", STR_PAD_LEFT):str_pad((int)substr($id, 4, strlen($id)), 12, "0", STR_PAD_LEFT);
    }
}
