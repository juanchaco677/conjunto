<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DetallesMovimiento extends Model
{
    //
}
