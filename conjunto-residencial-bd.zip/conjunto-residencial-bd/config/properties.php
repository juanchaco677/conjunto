<?php
return [

		'MSG_NOMBRE_UNO' => 'El campo nombre es obligatorio.',
		'MSG_APELLIDO_UNO' => 'El campo apellido es obligatorio.',
		'MSG_CORREO' => 'El campo correo es obligatorio.',
		'MSG_CONTRASENA' => 'El campo contraseña es obligatorio.',
		'MSG_CONJUNTO' => 'El campo conjunto residencial es obligatorio.',
		'MSG_CUOTA' => 'El conjunto requiere una cuota de aministración anual.',
		'MSG_NOMBRE_CONJUNTO' => 'El campo nombre del conjunto es obligatorio.',
		'MSG_DIRECCION_CONJUNTO' => 'El campo direccion del conjunto es obligatorio.',
		'MSG_ADMINISTRADOR'=>'Se requiere crear el administrador del conjunto residencial.',
		'MSG_ANO'=>'El ano es un campo obligatorio.',
		'MSG_FACTURA'=>'La factura es un campo obligatorio.',	
		'MSG_PRO_INQUI'=>'El usuario propietario debe estar asociado a la obligación.',
		'MSG_BUSCAR'=>'El campo de busqueda es obligatorio.',
		'MSG_ID'=>'No se encontro identificador o llave.',
		
	];
