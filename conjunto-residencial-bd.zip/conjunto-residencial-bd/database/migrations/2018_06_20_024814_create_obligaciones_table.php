<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateObligacionesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('obligaciones', function (Blueprint $table) {
            $table->string('id',15)->primary();
           
            $table->string('id_factura',15);
            $table->foreign('id_factura')->references('id')->on('facturas');
            $table->string('id_propietario_inquilino',15);
            $table->foreign('id_propietario_inquilino')->references('id')->on('usuarios');
            $table->integer('id_ano')->unsigned();
            $table->foreign('id_ano')
                ->references('id')
                ->on('anos');
            $table->timestamps();
          
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('obligaciones');
    }
}
