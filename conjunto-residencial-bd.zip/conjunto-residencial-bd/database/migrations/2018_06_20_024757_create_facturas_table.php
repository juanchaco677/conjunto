<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateFacturasTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('facturas', function (Blueprint $table) {
            $table->string('id',15)->primary();
            $table->double('saldo_otros')->default(0);
            $table->double('saldo_cuota_mes')->default(0);
            $table->double('total_saldo_pagar')->default(0);
            $table->enum('cod_factura', ['F', 'R']);
            $table->integer('ano');
            $table->date('fecha_inicial');
            $table->date('fecha_final');
            $table->timestamps();
            //COD_FACTURA:F=FACTURA,R=RECIBO;
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('facturas');
    }
}
