<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateCuotasAdministracionsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('cuotas_administracions', function (Blueprint $table) {
            $table->increments('id');
            $table->tinyInteger('ipc_incremento')->default(0);       
            $table->integer('valor_mensual')->default(0);
            $table->integer('id_ano')->unsigned();
            $table->foreign('id_ano')
                ->references('id')
                ->on('anos');
            $table->integer('id_conjunto')->unsigned();
            $table->foreign('id_conjunto')->references('id')->on('conjuntos_residencials');           
            $table->timestamps(); 
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('cuotas_administracions');
    }
}
