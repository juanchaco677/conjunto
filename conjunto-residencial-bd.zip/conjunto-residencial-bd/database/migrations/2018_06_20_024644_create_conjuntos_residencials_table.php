<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateConjuntosResidencialsTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('conjuntos_residencials', function (Blueprint $table) {
            $table->increments('id');
            $table->string('nombre',50);
            $table->string('direccion',60);
            $table->string('telefono',15)->nullable();
            $table->string('celular',10)->nullable();           
            $table->integer('id_coordenada')->unsigned()->nullable();
            $table->foreign('id_coordenada')->references('id')->on('coordenadas');
            $table->string('id_administrador',15);
            $table->foreign('id_administrador')->references('id')->on('usuarios');
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('conjuntos_residencials');
    }
}
