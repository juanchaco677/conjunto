<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateDetallesMovimientosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('detalles_movimientos', function (Blueprint $table) {
            $table->string('id_obligacion',15);
            $table->string('id_generado',15);
            $table->primary(array('id_obligacion','id_generado'));
            $table->foreign('id_generado')->references('id')->on('facturas');
            $table->foreign('id_obligacion')->references('id')->on('obligaciones');
            $table->double('concepto_valor')->default(0);
            $table->enum('cod_naturaleza', ['D', 'C']);
            $table->date('fecha_inicial');
            $table->date('fecha_final');
            $table->timestamps();
            //cod_naturaleza:D=DEBITO,C=CREDITO
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('detalles_movimientos');
    }
}
