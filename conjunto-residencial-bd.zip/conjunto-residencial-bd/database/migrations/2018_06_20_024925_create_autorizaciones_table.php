<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateAutorizacionesTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('autorizaciones', function (Blueprint $table) {
            $table->increments('id');
            $table->string('id_propietario',15);
            $table->foreign('id_propietario')->references('id')->on('usuarios');
            $table->string('id_inquilino',15);
            $table->foreign('id_inquilino')->references('id')->on('usuarios');
            $table->enum('cod_estado', ['A', 'N'])->default('N');
            $table->timestamps();
            //cod_estado:A=AUTORIZADO,N=NO AUTORIZADO
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('autorizaciones');
    }
}
