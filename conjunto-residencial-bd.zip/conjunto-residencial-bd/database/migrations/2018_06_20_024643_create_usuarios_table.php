<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateUsuariosTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('usuarios', function (Blueprint $table) {
            $table->string('id',15);
            $table->primary('id');
            $table->string('nombre_uno',30);
            $table->string('nombre_dos',30)->nullable();
            $table->string('apellido_uno',30);
            $table->string('apellido_dos',30)->nullable();
            $table->string('email',70)->unique();
            $table->string('password');
            $table->string('alias')->nullable();
            $table->string('celular',10)->nullable();
            $table->string('telefono',10)->nullable();        
            $table->string('id_admi_pro',15)->nullable();
            $table->foreign('id_admi_pro')
                ->references('id')
                ->on('usuarios');
            $table->enum('tipo', ['A', 'P','I','S'])->default('S');
            $table->timestamps();
            //TIPO:A=ADMINISTRADOR CONJUNTO,P=PROPIETARIO,I=INQUILINO,S=ADMINISTRADOR DEL SISTEMA
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('usuarios');
    }
}
